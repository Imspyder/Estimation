package com.vehicle.main.repository;

import com.vehicle.main.entity.FileProcessingLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FileProcessingRepository extends JpaRepository<FileProcessingLog,Long> {
}
